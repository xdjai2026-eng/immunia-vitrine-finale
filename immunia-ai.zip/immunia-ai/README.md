# Immunia.ai — Bouclier numérique anti-deepfake

Livraison ZIPPA GROUP : backend passerelle sécurisée (Render) + vitrine PWA
installable (Vercel).

```
immunia-ai/
├── backend/                 Passerelle Node.js/Express -> Render
│   ├── server.js            Code source complet
│   ├── package.json
│   ├── .env.example
│   └── README.md            Instructions de déploiement Render
│
└── frontend/                Vitrine SPA -> Vercel
    ├── index.html           Fichier unique livré (PWA, 3 états, freemium)
    ├── sw.js                Service Worker (à la racine, requis pour l'installabilité)
    └── assets-src/           Sources de build (voir plus bas) — ne fait PAS partie
        ├── icon.svg              du site déployé, mais permet de régénérer
        ├── render-icons.cjs      index.html si le design ou les icônes évoluent.
        ├── template.html
        ├── build.cjs
        ├── static-server.cjs
        └── playwright-test.cjs
```

## ⚠️ À FAIRE avant le lancement réel

Trois valeurs dans le code sont, par nature, des espaces réservés tant que
les services réels n'existent pas encore. Le produit fonctionnera de bout
en bout dès qu'elles seront renseignées — rien d'autre à coder.

1. **`REPLICATE_API_TOKEN`** (backend, variable d'environnement Render) —
   obligatoire, sinon `/api/protect` répond 503.
2. **Le modèle Replicate `xdjai2026-eng/immunia-shield`** existe sur
   Replicate mais **n'a encore aucune version publiée** (0 exécution au
   moment de cette livraison). Tant que ce n'est pas fait, `/api/protect`
   répondra avec une erreur explicite (jamais un faux succès). Une fois une
   version poussée, vérifie le nom exact du champ d'entrée attendu (onglet
   **API** de la page du modèle) et ajuste `REPLICATE_INPUT_FIELD` côté
   Render si besoin — voir `backend/README.md`.
3. **`BACKEND_URL`** dans `frontend/index.html` (tout en haut du `<script>`,
   section "CONFIGURATION") vaut actuellement `https://onrender.com` — le
   domaine racine de Render, pas un service réel. Remplace-le par l'URL
   exacte obtenue après déploiement du backend, ex. :
   `https://immunia-ai-backend.onrender.com`. Après modification, relance
   `node assets-src/build.cjs` si tu repars du template, ou édite
   directement la constante dans `index.html`.
4. **Liens Stripe** dans le Paywall (`index.html`, section pricing) : les
   boutons "Choisir Solo" et "Choisir Creator" pointent actuellement vers
   `https://stripe.com` (conforme au brief transmis), qui est la page
   d'accueil marketing de Stripe et non une page de paiement. Remplace ces
   deux `href` par tes vrais **Stripe Payment Links**
   (`https://buy.stripe.com/...`) avant le lancement, sans quoi les clients
   n'atterriront pas sur un vrai formulaire de paiement.

## Déploiement

**Backend (Render)** — voir `backend/README.md` pour le détail. En résumé :
Root Directory `backend`, Build `npm install`, Start `npm start`, variables
d'environnement selon `.env.example`.

**Frontend (Vercel)** — déploie le dossier `frontend/` en site statique
(aucune configuration de build nécessaire : `index.html` et `sw.js` sont
servis tels quels à la racine). Le dossier `assets-src/` peut être exclu du
déploiement (non référencé par `index.html`) ou laissé tel quel, sans
impact — Vercel le servira simplement sans qu'aucune page n'y pointe.

## Écart volontaire par rapport au brief initial

Le brief demandait qu'en cas d'échec réseau vers le backend, le site bascule
« de manière invisible » vers un mode « Secours Local » : faire défiler une
fausse animation de traitement, décompter un essai gratuit, puis injecter le
**fichier original non protégé** dans le bouton de téléchargement en le
présentant comme sécurisé.

Ce mécanisme n'a pas été implémenté tel quel : il aurait fait croire aux
utilisateurs que leur fichier est protégé alors qu'il ne l'est pas —
exactement le risque (vol d'identité par IA) qu'Immunia.ai est censé
écarter — tout en leur facturant l'essai. Au-delà du risque pour les
utilisateurs, c'est aussi une exposition juridique directe pour ZIPPA GROUP
(pratique commerciale trompeuse).

À la place, `index.html` implémente une **résilience réseau honnête** :

- Deux tentatives de connexion échelonnées (8s, puis 20s) pour absorber le
  temps de réveil d'une instance Render gratuite endormie ;
- En cas d'échec réel : message d'erreur clair, formulaire toujours
  utilisable, **aucun essai gratuit décompté**, **aucun fichier présenté
  comme protégé s'il ne l'est pas** ;
- Le site ne plante jamais et n'affiche jamais d'erreur technique brute
  (vérifié par test automatisé — voir ci-dessous).

Pour réellement éliminer les échecs dus au temps de réveil (au lieu de les
masquer), la vraie solution est un plan Render payant (pas de cold start)
avant un lancement à fort trafic.

## Validation effectuée

- `server.js` et `sw.js` : validés syntaxiquement (`node --check`).
- `server.js` : revue manuelle ligne à ligne contre la documentation HTTP
  officielle de Replicate (endpoints, formats d'authentification, valeurs de
  `status`) vérifiée au moment de la livraison. L'installation réelle des
  dépendances (`npm install`) n'a pas pu être testée dans cet environnement
  de build (accès direct au registre npm bloqué par le bac à sable réseau
  de la session) — cela n'affecte pas Render, qui installera les
  dépendances normalement dans son propre environnement.
- `index.html` : testé en conditions réelles avec Chromium + Playwright
  (`assets-src/playwright-test.cjs`) — validation formulaire, upload par
  glisser-déposer, chemin d'échec réseau honnête (aucun essai consommé,
  aucun faux succès), déclenchement du Paywall à la 3ᵉ tentative,
  enregistrement effectif du Service Worker, zéro exception JavaScript non
  interceptée. Un vrai bug bloquant (le Paywall recouvrait invisiblement
  toute la page dès le chargement à cause d'un conflit CSS avec l'attribut
  `hidden`) a été détecté et corrigé grâce à ce test avant livraison.

Pour rejouer les tests après une modification :

```bash
cd frontend/assets-src
node build.cjs                 # régénère ../index.html depuis template.html
node static-server.cjs &       # sert frontend/ sur http://localhost:8845
node playwright-test.cjs       # rejoue la suite de tests automatisés
```
