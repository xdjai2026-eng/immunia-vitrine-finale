// One-off runtime smoke test (not shipped). Loads the real, built
// frontend/index.html in headless Chromium and exercises the actual state
// machine: form validation, the honest failure path (no free-trial token
// consumed, no fake success on network failure), and the paywall trigger.
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BASE_URL = 'http://localhost:8845';
const SHOT_DIR = path.join(__dirname, 'screenshots');
fs.mkdirSync(SHOT_DIR, { recursive: true });

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium/chrome-linux/chrome' }).catch(async () => {
    // Fallback: let Playwright resolve its own configured executable.
    return chromium.launch();
  });
  const context = await browser.newContext({ viewport: { width: 420, height: 860 } });
  const page = await context.newPage();

  const pageErrors = [];
  const consoleMessages = [];
  page.on('pageerror', (err) => pageErrors.push(String(err)));
  page.on('console', (msg) => consoleMessages.push(`[${msg.type()}] ${msg.text()}`));

  console.log('--- 1. Chargement initial ---');
  await page.goto(BASE_URL + '/', { waitUntil: 'load' });
  await page.waitForSelector('#view-form:not([hidden])', { timeout: 5000 });
  await page.screenshot({ path: path.join(SHOT_DIR, '01-form.png') });

  const headChecks = await page.evaluate(() => {
    const manifestHref = document.querySelector('link[rel="manifest"]')?.href || '';
    const appleIconHref = document.querySelector('link[rel="apple-touch-icon"]')?.href || '';
    const svgIconHref = document.querySelector('link[rel="icon"][type="image/svg+xml"]')?.href || '';
    const themeColor = document.querySelector('meta[name="theme-color"]')?.content || '';
    const appleCapable = document.querySelector('meta[name="apple-mobile-web-app-capable"]')?.content || '';
    return { manifestHref: manifestHref.slice(0, 40), appleIconHref: appleIconHref.slice(0, 30), svgIconHref: svgIconHref.slice(0, 30), themeColor, appleCapable };
  });
  console.log('Head checks:', headChecks);

  console.log('--- 2. Validation du formulaire (champs vides) ---');
  await page.click('#submit-btn');
  const fullnameError = await page.textContent('#fullname-error');
  console.log('Erreur nom (attendu non-vide):', JSON.stringify(fullnameError));
  if (!fullnameError) throw new Error('La validation cote client ne bloque pas un formulaire vide.');

  console.log('--- 3. Remplissage + upload + soumission ---');
  await page.fill('#fullname', 'Jean Dupont');
  await page.fill('#email', 'jean.dupont@example.com');

  const testImage = fs.readFileSync(path.join(__dirname, 'icon-192.png'));
  await page.setInputFiles('#file-input', {
    name: 'selfie-test.png',
    mimeType: 'image/png',
    buffer: testImage,
  });

  const fileChipVisible = await page.isVisible('#file-chip');
  console.log('Chip de fichier visible apres selection:', fileChipVisible);
  if (!fileChipVisible) throw new Error('Le chip de fichier ne s\'affiche pas apres selection.');

  const attemptsBefore = await page.evaluate(() => sessionStorage.getItem('immunia_attempts'));
  console.log('Essais avant soumission:', attemptsBefore);

  await page.click('#submit-btn');

  // Le traitement doit passer par l'etat "processing" (retroaction visible)
  await page.waitForSelector('#processing:not([hidden])', { timeout: 3000 });
  await page.screenshot({ path: path.join(SHOT_DIR, '02-processing.png') });
  console.log('Etat "processing" affiche : OK');

  console.log('--- 4. Attente du resultat (succes ou echec honnete) ---');
  await page.waitForFunction(
    () => {
      const err = document.getElementById('error-banner');
      const success = document.getElementById('view-success');
      return (err && !err.hidden) || (success && !success.hidden);
    },
    { timeout: 35000 }
  );
  await page.screenshot({ path: path.join(SHOT_DIR, '03-result.png') });

  const outcome = await page.evaluate(() => {
    const err = document.getElementById('error-banner');
    const success = document.getElementById('view-success');
    return {
      errorShown: err && !err.hidden,
      errorText: document.getElementById('error-message')?.textContent || '',
      successShown: success && !success.hidden,
      downloadHref: document.getElementById('download-btn')?.getAttribute('href') || '',
      attemptsAfter: sessionStorage.getItem('immunia_attempts'),
    };
  });
  console.log('Resultat:', outcome);

  if (outcome.errorShown) {
    if (outcome.attemptsAfter !== attemptsBefore) {
      throw new Error(
        `ECHEC LOGIQUE CRITIQUE : un essai gratuit a ete decompte malgre un echec reseau ` +
        `(avant=${attemptsBefore}, apres=${outcome.attemptsAfter}). Aucun essai ne doit etre ` +
        `consomme sans succes reel.`
      );
    }
    if (outcome.downloadHref && outcome.downloadHref !== '#') {
      throw new Error('ECHEC LOGIQUE CRITIQUE : un lien de telechargement a ete pose malgre un echec.');
    }
    console.log('Chemin d\'echec reseau : comportement honnete confirme (aucun essai consomme, aucun faux succes).');
  } else if (outcome.successShown) {
    console.log('Le backend a repondu avec succes (inattendu dans ce bac a sable reseau restreint, mais logique correcte si cela arrive).');
    if (outcome.attemptsAfter !== '1') {
      throw new Error(`Essai attendu a 1 apres un succes reel, obtenu: ${outcome.attemptsAfter}`);
    }
  }

  console.log('--- 5. Bouton "nouveau fichier" ramene au formulaire ---');
  if (outcome.successShown) {
    await page.click('#new-file-btn');
    await page.waitForSelector('#view-form:not([hidden])', { timeout: 3000 });
  } else {
    // Sur le chemin d'erreur, le formulaire reste affiche (le fichier est conserve
    // pour permettre un "Reessayer" en un clic) : on verifie juste que le bandeau
    // d'erreur reste correctement affiche et que le formulaire est toujours utilisable.
    const formStillUsable = await page.isEnabled('#submit-btn');
    console.log('Formulaire encore utilisable apres echec:', formStillUsable);
    if (!formStillUsable) throw new Error('Le formulaire reste desactive apres un echec.');
  }

  console.log('--- 6. Verification du Service Worker ---');
  await page.waitForTimeout(1200);
  const swState = await page.evaluate(async () => {
    const regs = await navigator.serviceWorker.getRegistrations();
    return { count: regs.length, scopes: regs.map((r) => r.scope) };
  });
  console.log('Service Worker enregistrements:', swState);
  if (swState.count < 1) throw new Error('Le Service Worker ne s\'est pas enregistre.');

  console.log('--- 7. Declenchement du Paywall (limite atteinte + rechargement) ---');
  await page.evaluate(() => sessionStorage.setItem('immunia_attempts', '2'));
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('#paywall:not([hidden])', { timeout: 5000 });
  await page.screenshot({ path: path.join(SHOT_DIR, '04-paywall.png') });

  const paywallChecks = await page.evaluate(() => {
    const appInert = document.getElementById('app').hasAttribute('inert');
    const priceCards = document.querySelectorAll('.price-card').length;
    const stripeLinks = Array.from(document.querySelectorAll('.price-card a'))
      .map((a) => a.getAttribute('href'));
    return { appInert, priceCards, stripeLinks };
  });
  console.log('Paywall:', paywallChecks);
  if (paywallChecks.priceCards !== 3) throw new Error(`Attendu 3 cartes tarifaires, trouve ${paywallChecks.priceCards}`);

  console.log('\n--- Erreurs JS non interceptees (pageerror) ---');
  console.log(pageErrors.length ? pageErrors : '(aucune)');

  console.log('\n--- Messages console de type "error" ---');
  const consoleErrors = consoleMessages.filter((m) => m.startsWith('[error]'));
  console.log(consoleErrors.length ? consoleErrors.join('\n') : '(aucun)');

  await browser.close();

  if (pageErrors.length > 0) {
    console.error('\nECHEC : des erreurs JavaScript non interceptees ont ete detectees.');
    process.exit(1);
  }

  console.log('\n=== TOUS LES TESTS RUNTIME ONT REUSSI ===');
})().catch((err) => {
  console.error('\nECHEC DU TEST :', err);
  process.exit(1);
});
