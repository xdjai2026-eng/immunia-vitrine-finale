// Build-time helper (not shipped): rasterizes icon.svg into the PNG sizes
// needed for the manifest / apple-touch-icon, then base64-encodes each one
// so the strings can be pasted straight into index.html as data: URIs.
const sharp = require("sharp");
const { readFileSync, writeFileSync } = require("fs");
const path = require("path");

const dir = __dirname;
const svg = readFileSync(path.join(dir, "icon.svg"));
const sizes = [180, 192, 512];

(async () => {
  for (const size of sizes) {
    const buf = await sharp(svg, { density: 384 })
      .resize(size, size)
      .png({ compressionLevel: 9 })
      .toBuffer();
    writeFileSync(path.join(dir, `icon-${size}.png`), buf);
    const b64 = buf.toString("base64");
    writeFileSync(path.join(dir, `icon-${size}.b64`), b64);
    console.log(`icon-${size}.png -> ${buf.length} bytes, base64 length ${b64.length}`);
  }

  const svgB64 = Buffer.from(svg).toString("base64");
  writeFileSync(path.join(dir, "icon.svg.b64"), svgB64);
  console.log(`icon.svg -> base64 length ${svgB64.length}`);
})();
