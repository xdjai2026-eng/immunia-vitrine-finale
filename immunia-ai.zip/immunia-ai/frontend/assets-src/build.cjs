// Build-time helper (not shipped): assembles frontend/index.html from
// template.html by injecting the base64-encoded icons and a generated
// manifest.json (itself embedded as a base64 data: URI, so the final
// index.html stays a single, self-contained file as required).
const { readFileSync, writeFileSync } = require('fs');
const path = require('path');

const dir = __dirname;
const frontendDir = path.join(dir, '..');

const svgB64 = readFileSync(path.join(dir, 'icon.svg.b64'), 'utf8').trim();
const png180B64 = readFileSync(path.join(dir, 'icon-180.b64'), 'utf8').trim();
const png192B64 = readFileSync(path.join(dir, 'icon-192.b64'), 'utf8').trim();
const png512B64 = readFileSync(path.join(dir, 'icon-512.b64'), 'utf8').trim();

const svgDataUri = `data:image/svg+xml;base64,${svgB64}`;
const png180DataUri = `data:image/png;base64,${png180B64}`;
const png192DataUri = `data:image/png;base64,${png192B64}`;
const png512DataUri = `data:image/png;base64,${png512B64}`;

const manifest = {
  id: '/',
  name: 'Immunia.ai — Bouclier Numérique',
  short_name: 'Immunia.ai',
  description:
    "Protection de votre identité numérique contre les deepfakes, le face-swap et le clonage vocal par intelligence artificielle.",
  lang: 'fr',
  dir: 'ltr',
  start_url: '/',
  scope: '/',
  display: 'standalone',
  orientation: 'portrait-primary',
  background_color: '#020617',
  theme_color: '#020617',
  categories: ['security', 'utilities', 'photo'],
  icons: [
    { src: svgDataUri, sizes: 'any', type: 'image/svg+xml', purpose: 'any' },
    { src: png180DataUri, sizes: '180x180', type: 'image/png', purpose: 'any' },
    { src: png192DataUri, sizes: '192x192', type: 'image/png', purpose: 'any' },
    { src: png192DataUri, sizes: '192x192', type: 'image/png', purpose: 'maskable' },
    { src: png512DataUri, sizes: '512x512', type: 'image/png', purpose: 'any' },
    { src: png512DataUri, sizes: '512x512', type: 'image/png', purpose: 'maskable' },
  ],
};

const manifestB64 = Buffer.from(JSON.stringify(manifest)).toString('base64');

let html = readFileSync(path.join(dir, 'template.html'), 'utf8');

const replacements = {
  __SVG_ICON_B64__: svgB64,
  __PNG_180_B64__: png180B64,
  __PNG_192_B64__: png192B64,
  __PNG_512_B64__: png512B64,
  __MANIFEST_B64__: manifestB64,
};

let missing = [];
for (const [token, value] of Object.entries(replacements)) {
  if (!html.includes(token)) {
    missing.push(token);
    continue;
  }
  html = html.split(token).join(value);
}

if (missing.length) {
  console.error('Jetons introuvables dans le template :', missing.join(', '));
  process.exit(1);
}

const leftover = html.match(/__[A-Z0-9_]+__/g);
if (leftover) {
  console.error('Jetons non substitués restants :', leftover.join(', '));
  process.exit(1);
}

writeFileSync(path.join(frontendDir, 'index.html'), html);
console.log(`index.html généré -> ${html.length} caractères (${(html.length / 1024).toFixed(1)} Ko)`);
