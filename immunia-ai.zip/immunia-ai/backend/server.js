/**
 * Immunia.ai — Backend passerelle sécurisée
 * ------------------------------------------------------------------------
 * Rôle : ce serveur est le SEUL composant à connaître la clé API Replicate.
 * Le client (index.html sur Vercel) ne voit jamais process.env.REPLICATE_API_TOKEN :
 * il envoie le média au backend, le backend l'envoie à Replicate, et relaie
 * les réponses. C'est le modèle "coffre-fort" demandé dans les spécifications.
 *
 * Routes exposées :
 *   GET  /health              -> sonde de vie (utilisée par Render)
 *   POST /api/protect         -> crée une prédiction Replicate (démarre le traitement GPU)
 *   GET  /api/status/:id      -> interroge l'état d'une prédiction (polling)
 *
 * Déploiement cible : Render (Web Service Node.js)
 *   Build command : npm install
 *   Start command : npm start   (ou: node server.js)
 *   Variables d'environnement requises : voir .env.example
 * ------------------------------------------------------------------------
 */

'use strict';

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

// ---------------------------------------------------------------------------
// 1. Configuration (entièrement pilotée par variables d'environnement)
// ---------------------------------------------------------------------------

const PORT = parseInt(process.env.PORT, 10) || 10000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const IS_PROD = NODE_ENV === 'production';

const REPLICATE_API_TOKEN = process.env.REPLICATE_API_TOKEN || '';

// Le modèle est fourni au format "proprietaire/nom", ex: xdjai2026-eng/immunia-shield
const REPLICATE_MODEL = process.env.REPLICATE_MODEL || 'xdjai2026-eng/immunia-shield';
const [REPLICATE_MODEL_OWNER, REPLICATE_MODEL_NAME] = REPLICATE_MODEL.split('/');

// Nom du champ d'entrée attendu par le modèle Replicate pour le média (data URI).
// Le modèle xdjai2026-eng/immunia-shield n'a, à ce jour, aucune version publiée
// (donc aucun schéma d'entrée public) : "image" est l'usage le plus courant sur
// Replicate pour ce type de modèle, mais ZIPPA doit vérifier ce nom de champ dès
// qu'une version est poussée et ajuster REPLICATE_INPUT_FIELD si besoin, sans
// avoir à modifier ce fichier.
const REPLICATE_INPUT_FIELD = process.env.REPLICATE_INPUT_FIELD || 'image';

// Taille maximale acceptée pour un média encodé en base64 (photo/vidéo/audio).
const MAX_UPLOAD_MB = parseInt(process.env.MAX_UPLOAD_MB, 10) || 30;
const MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024;
// La charge JSON (data URI + enveloppe) est ~33% plus grosse que le fichier
// binaire d'origine à cause de l'encodage base64 ; on prévoit une marge.
const JSON_BODY_LIMIT = `${Math.ceil(MAX_UPLOAD_MB * 1.4)}mb`;

// Origines autorisées à appeler cette API en cross-origin (CORS).
// - On accepte une liste explicite via ALLOWED_ORIGINS (séparée par des virgules),
//   à renseigner avec l'URL réelle de la vitrine une fois déployée sur Vercel
//   (ex: https://immunia-ai.vercel.app). "https://vercel.app" seul, tel que
//   mentionné dans le brief, n'est jamais l'origine d'une application déployée
//   (c'est le domaine racine de Vercel) : on l'accepte donc EN PLUS d'une règle
//   qui autorise automatiquement tout sous-domaine *.vercel.app (déploiements
//   de prod et de preview), pour que la vitrine fonctionne sans réglage manuel
//   à chaque redéploiement.
const EXTRA_ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

const VERCEL_ORIGIN_REGEX = /^https:\/\/([a-z0-9-]+\.)*vercel\.app$/i;
const LOCALHOST_ORIGIN_REGEX = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i;

// Garde-fous anti-abus sur la route coûteuse (appelle un GPU facturé).
const RATE_LIMIT_WINDOW_MS = parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000; // 15 min
const RATE_LIMIT_MAX = parseInt(process.env.RATE_LIMIT_MAX, 10) || 30;

if (!REPLICATE_API_TOKEN) {
  // On ne fait pas planter le process (Render redémarrerait en boucle) :
  // on le signale bruyamment dans les logs et chaque route qui en a besoin
  // répondra 503 tant que la variable n'est pas configurée.
  // eslint-disable-next-line no-console
  console.error(
    '[immunia-backend] ATTENTION : REPLICATE_API_TOKEN est absent des variables ' +
    "d'environnement. Configure-le dans le dashboard Render avant de recevoir du trafic."
  );
}

// ---------------------------------------------------------------------------
// 2. App Express
// ---------------------------------------------------------------------------

const app = express();

// Render (comme tout PaaS) place le service derrière un reverse proxy.
// Sans ce réglage, req.ip et donc le rate-limiter verraient l'IP du proxy
// et non celle du client, et express-rate-limit lève une erreur de validation.
app.set('trust proxy', 1);

app.use(helmet());
app.disable('x-powered-by');

app.use(
  cors({
    origin(origin, callback) {
      // Pas d'en-tête Origin (curl, appel serveur-à-serveur, health check) -> autorisé.
      if (!origin) return callback(null, true);

      const isAllowed =
        EXTRA_ALLOWED_ORIGINS.includes(origin) ||
        VERCEL_ORIGIN_REGEX.test(origin) ||
        (!IS_PROD && LOCALHOST_ORIGIN_REGEX.test(origin));

      if (isAllowed) return callback(null, true);

      return callback(new Error(`Origin non autorisée par la politique CORS : ${origin}`));
    },
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type'],
    maxAge: 86400,
  })
);

app.use(express.json({ limit: JSON_BODY_LIMIT }));

// Journalisation minimale : jamais le corps de la requête (qui contient le
// média en base64), seulement méthode/route/statut/durée.
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - start;
    // eslint-disable-next-line no-console
    console.log(`[immunia-backend] ${req.method} ${req.path} -> ${res.statusCode} (${ms}ms)`);
  });
  next();
});

// ---------------------------------------------------------------------------
// 3. Limiteur de débit sur les routes qui consomment du GPU / interrogent Replicate
// ---------------------------------------------------------------------------

const apiLimiter = rateLimit({
  windowMs: RATE_LIMIT_WINDOW_MS,
  max: RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Trop de requêtes. Merci de réessayer dans quelques minutes.',
  },
});

// ---------------------------------------------------------------------------
// 4. Utilitaires
// ---------------------------------------------------------------------------

/**
 * Sépare un data URI ("data:<mime>;base64,<data>") en { mime, data }.
 * Si la chaîne fournie n'est pas un data URI, elle est traitée comme du
 * base64 brut et un type MIME par défaut lui est attribué.
 */
function parseBase64Payload(raw, fallbackMime) {
  if (typeof raw !== 'string' || raw.length === 0) {
    return null;
  }

  const dataUriMatch = raw.match(/^data:([^;,]+);base64,(.+)$/s);
  if (dataUriMatch) {
    return { mime: dataUriMatch[1], data: dataUriMatch[2] };
  }

  return { mime: fallbackMime || 'application/octet-stream', data: raw };
}

/** Estime la taille en octets d'une charge base64 sans la décoder entièrement. */
function estimateBase64Bytes(base64String) {
  const len = base64String.length;
  const padding = base64String.endsWith('==') ? 2 : base64String.endsWith('=') ? 1 : 0;
  return Math.floor((len * 3) / 4) - padding;
}

/** Vérifie qu'un identifiant de prédiction Replicate a une forme plausible. */
function isValidPredictionId(id) {
  return typeof id === 'string' && /^[A-Za-z0-9]{1,64}$/.test(id);
}

/** Effectue un fetch vers Replicate avec timeout, sans jamais logger le token. */
async function callReplicate(url, options, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${REPLICATE_API_TOKEN}`,
        'Content-Type': 'application/json',
        ...(options && options.headers ? options.headers : {}),
      },
    });
    return response;
  } finally {
    clearTimeout(timer);
  }
}

/** Extrait un message d'erreur lisible depuis une réponse d'erreur Replicate. */
async function extractReplicateError(response) {
  try {
    const body = await response.json();
    return body.detail || body.error || body.title || JSON.stringify(body);
  } catch (_err) {
    return `Réponse Replicate illisible (HTTP ${response.status})`;
  }
}

// ---------------------------------------------------------------------------
// 5. Routes
// ---------------------------------------------------------------------------

app.get('/', (_req, res) => {
  res.json({
    service: 'immunia-ai-backend',
    status: 'ok',
    model: REPLICATE_MODEL,
  });
});

// Sonde de vie utilisée par Render pour savoir si l'instance est prête.
app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    replicateConfigured: Boolean(REPLICATE_API_TOKEN),
    model: REPLICATE_MODEL,
    time: new Date().toISOString(),
  });
});

/**
 * POST /api/protect
 * Reçoit { image_base64, mime_type?, extra_input? }, crée une prédiction
 * Replicate et répond immédiatement avec l'identifiant à interroger via
 * /api/status/:id (mode asynchrone : pas d'attente bloquante du GPU ici).
 */
app.post('/api/protect', apiLimiter, async (req, res) => {
  if (!REPLICATE_API_TOKEN) {
    return res.status(503).json({
      error: "Le service n'est pas encore configuré (clé API Replicate manquante côté serveur).",
    });
  }

  if (!REPLICATE_MODEL_OWNER || !REPLICATE_MODEL_NAME) {
    return res.status(500).json({
      error: 'Configuration serveur invalide : REPLICATE_MODEL doit être au format "proprietaire/nom".',
    });
  }

  const { image_base64: imageBase64, mime_type: mimeType, extra_input: extraInput } = req.body || {};

  if (!imageBase64 || typeof imageBase64 !== 'string') {
    return res.status(400).json({
      error: 'Champ "image_base64" manquant ou invalide dans le corps de la requête.',
    });
  }

  const parsed = parseBase64Payload(imageBase64, mimeType);
  if (!parsed || !parsed.data) {
    return res.status(400).json({ error: "Impossible d'interpréter le média fourni." });
  }

  const estimatedBytes = estimateBase64Bytes(parsed.data);
  if (estimatedBytes > MAX_UPLOAD_BYTES) {
    return res.status(413).json({
      error: `Fichier trop volumineux (limite : ${MAX_UPLOAD_MB} Mo).`,
    });
  }

  if (extraInput !== undefined && (typeof extraInput !== 'object' || extraInput === null || Array.isArray(extraInput))) {
    return res.status(400).json({ error: '"extra_input" doit être un objet JSON.' });
  }

  const dataUri = `data:${parsed.mime};base64,${parsed.data}`;

  const replicateInput = {
    [REPLICATE_INPUT_FIELD]: dataUri,
    ...(extraInput || {}),
  };

  try {
    const replicateResponse = await callReplicate(
      `https://api.replicate.com/v1/models/${REPLICATE_MODEL_OWNER}/${REPLICATE_MODEL_NAME}/predictions`,
      {
        method: 'POST',
        body: JSON.stringify({ input: replicateInput }),
      },
      20000 // 20s : le temps de création d'une prédiction, pas du traitement GPU lui-même
    );

    if (!replicateResponse.ok) {
      const message = await extractReplicateError(replicateResponse);
      // eslint-disable-next-line no-console
      console.error(`[immunia-backend] Replicate a refusé la création de prédiction (HTTP ${replicateResponse.status}): ${message}`);
      return res.status(502).json({
        error: "Le service de protection GPU a refusé la requête.",
        detail: message,
      });
    }

    const prediction = await replicateResponse.json();

    return res.status(202).json({
      id: prediction.id,
      status: prediction.status,
      created_at: prediction.created_at,
    });
  } catch (err) {
    if (err.name === 'AbortError') {
      // eslint-disable-next-line no-console
      console.error('[immunia-backend] Timeout lors de la création de la prédiction Replicate.');
      return res.status(504).json({ error: 'Le service de protection GPU met trop de temps à répondre.' });
    }
    // eslint-disable-next-line no-console
    console.error('[immunia-backend] Erreur réseau vers Replicate :', err.message);
    return res.status(502).json({ error: 'Impossible de joindre le service de protection GPU.' });
  }
});

/**
 * GET /api/status/:id
 * Relaie l'état d'une prédiction Replicate en cours pour permettre au client
 * de faire du polling ("Chargement... 40%... Terminé").
 */
app.get('/api/status/:id', apiLimiter, async (req, res) => {
  if (!REPLICATE_API_TOKEN) {
    return res.status(503).json({
      error: "Le service n'est pas encore configuré (clé API Replicate manquante côté serveur).",
    });
  }

  const { id } = req.params;
  if (!isValidPredictionId(id)) {
    return res.status(400).json({ error: 'Identifiant de prédiction invalide.' });
  }

  try {
    const replicateResponse = await callReplicate(
      `https://api.replicate.com/v1/predictions/${id}`,
      { method: 'GET' },
      15000
    );

    if (replicateResponse.status === 404) {
      return res.status(404).json({ error: 'Prédiction introuvable.' });
    }

    if (!replicateResponse.ok) {
      const message = await extractReplicateError(replicateResponse);
      // eslint-disable-next-line no-console
      console.error(`[immunia-backend] Erreur Replicate au polling (HTTP ${replicateResponse.status}): ${message}`);
      return res.status(502).json({ error: 'Le service de protection GPU est indisponible.', detail: message });
    }

    const prediction = await replicateResponse.json();

    return res.json({
      id: prediction.id,
      status: prediction.status, // starting | processing | succeeded | failed | canceled
      output: prediction.output ?? null,
      error: prediction.error ?? null,
      metrics: prediction.metrics ?? null,
    });
  } catch (err) {
    if (err.name === 'AbortError') {
      return res.status(504).json({ error: 'Le service de protection GPU met trop de temps à répondre.' });
    }
    // eslint-disable-next-line no-console
    console.error('[immunia-backend] Erreur réseau vers Replicate :', err.message);
    return res.status(502).json({ error: 'Impossible de joindre le service de protection GPU.' });
  }
});

// ---------------------------------------------------------------------------
// 6. Gestion des erreurs & routes inconnues
// ---------------------------------------------------------------------------

app.use((req, res) => {
  res.status(404).json({ error: `Route inconnue : ${req.method} ${req.path}` });
});

// Middleware d'erreur centralisé : intercepte notamment les JSON malformés
// (express.json déclenche un SyntaxError) et les rejets CORS.
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && 'body' in err) {
    return res.status(400).json({ error: 'Corps de requête JSON malformé.' });
  }

  if (err && /CORS/i.test(err.message || '')) {
    return res.status(403).json({ error: err.message });
  }

  // eslint-disable-next-line no-console
  console.error('[immunia-backend] Erreur non gérée :', err);
  return res.status(500).json({
    error: 'Erreur interne du serveur.',
    ...(IS_PROD ? {} : { detail: err.message }),
  });
});

// ---------------------------------------------------------------------------
// 7. Démarrage & arrêt propre
// ---------------------------------------------------------------------------

const server = app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`[immunia-backend] Serveur démarré sur le port ${PORT} (env: ${NODE_ENV})`);
  // eslint-disable-next-line no-console
  console.log(`[immunia-backend] Modèle Replicate ciblé : ${REPLICATE_MODEL} (champ d'entrée: "${REPLICATE_INPUT_FIELD}")`);
});

function shutdown(signal) {
  // eslint-disable-next-line no-console
  console.log(`[immunia-backend] Signal ${signal} reçu, arrêt propre du serveur...`);
  server.close(() => {
    // eslint-disable-next-line no-console
    console.log('[immunia-backend] Serveur arrêté.');
    process.exit(0);
  });
  // Filet de sécurité si des connexions restent ouvertes trop longtemps.
  setTimeout(() => process.exit(1), 10000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

module.exports = app;
