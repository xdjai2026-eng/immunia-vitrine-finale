# Immunia.ai — Backend (Render)

Passerelle Node.js/Express qui garde `REPLICATE_API_TOKEN` côté serveur et relaie
les appels vers le modèle Replicate `xdjai2026-eng/immunia-shield`.

## Déploiement sur Render

1. Pousse ce dossier `backend/` dans un dépôt Git.
2. Sur [render.com](https://render.com) : **New +** → **Web Service**, connecte le dépôt.
3. Réglages :
   - **Root Directory** : `backend`
   - **Build Command** : `npm install`
   - **Start Command** : `npm start`
   - **Health Check Path** : `/health`
4. Onglet **Environment** : ajoute toutes les variables listées dans `.env.example`
   (au minimum `REPLICATE_API_TOKEN`). `PORT` est injecté automatiquement par
   Render, inutile de le définir.
5. Déploie. Une fois en ligne, note l'URL publique (ex. `https://immunia-ai-backend.onrender.com`)
   — c'est celle que le frontend doit appeler.
6. Une fois la vitrine déployée sur Vercel, ajoute son URL exacte dans la
   variable `ALLOWED_ORIGINS` et redéploie (les sous-domaines `*.vercel.app`
   sont déjà autorisés par défaut, cette variable sert surtout pour un futur
   domaine personnalisé).

## Important avant le lancement

Le modèle `xdjai2026-eng/immunia-shield` référencé dans les spécifications
existe sur Replicate mais **n'a, à ce jour, aucune version publiée** (0
exécution). Tant que ce n'est pas fait, `/api/protect` répondra avec une
erreur 502 explicite ("Le service de protection GPU a refusé la requête").
Avant le lancement :

1. Pousse une version fonctionnelle du modèle sur Replicate (Cog + `replicate push`).
2. Ouvre l'onglet **API** de la page du modèle pour connaître le nom exact du
   champ d'entrée attendu (image, input_image, media, etc.).
3. Si ce nom diffère de `image`, mets à jour la variable d'environnement
   `REPLICATE_INPUT_FIELD` sur Render — aucun changement de code requis.

## Local

```bash
cp .env.example .env   # puis renseigne REPLICATE_API_TOKEN
npm install
npm run dev
```

## Routes

| Méthode | Route              | Rôle                                              |
|---------|---------------------|----------------------------------------------------|
| GET     | `/health`           | Sonde de vie (utilisée par Render)                 |
| POST    | `/api/protect`      | Démarre une prédiction Replicate (async)           |
| GET     | `/api/status/:id`   | Interroge l'état d'une prédiction (polling client) |
